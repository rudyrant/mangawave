import express from "express";
import helmet from "helmet";
import multer from "multer";
import path from "path";
import session from "express-session";
import { fileURLToPath } from "url";
import { createSessionStore } from "./lib/session-store.js";
import { logAuditEvent } from "./lib/audit.js";
import { initDatabase, isPostgresEnabled } from "./lib/db.js";
import { getAllSeries, getSeriesBySlug, getChapter, createSeriesEntry, createChapterEntry, slugify, ensureBasePaths } from "./lib/library.js";
import { bumpSessionVersion, changePassword, completeEmailVerification, completePasswordReset, countUsers, createEmailVerification, createPasswordReset, createUser, ensureSeedAdmin, findUserById, getPasswordResetByToken, verifyUser } from "./lib/users.js";
import { addComment, deleteComment, getBookmarksForUser, getCommentsForChapter, getProgressForUser, getRecentComments, isSeriesBookmarked, toggleBookmark, upsertProgress } from "./lib/community.js";
import { consumeRateLimit, csrfProtection, enforceUniformTiming, ensureCsrfToken, generateCspNonce, rateLimit, sha256 } from "./lib/security.js";
import { emailDeliveryEnabled, emailVerificationEnabled, sendPasswordResetEmail, sendVerificationEmail } from "./lib/email.js";
import { uploadBuffer, getStorageSummary } from "./lib/storage.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT || 3000);
const appOrigin = (process.env.APP_ORIGIN || `http://127.0.0.1:${port}`).replace(/\/$/, "");
const recentAuthWindowMs = Number(process.env.RECENT_AUTH_MINUTES || 15) * 60 * 1000;
const upload = multer({ storage: multer.memoryStorage() });
const forgotPasswordMessage = "If that account exists, a reset process has been started.";

const trustProxy = process.env.TRUST_PROXY;
if (trustProxy) {
  const parsed = Number(trustProxy);
  app.set("trust proxy", Number.isNaN(parsed) ? trustProxy : parsed);
}

const authRateLimit = rateLimit({ bucket: "auth", windowMs: 10 * 60 * 1000, limit: Number(process.env.AUTH_RATE_LIMIT || 20) });
const forgotIpRateLimit = rateLimit({ bucket: "forgot-ip", windowMs: 10 * 60 * 1000, limit: Number(process.env.FORGOT_IP_RATE_LIMIT || 8) });
const verificationResendRateLimit = rateLimit({ bucket: "verify-resend-ip", windowMs: 10 * 60 * 1000, limit: Number(process.env.VERIFY_RESEND_IP_RATE_LIMIT || 6) });
const commentRateLimit = rateLimit({ bucket: "comment", windowMs: 60 * 1000, limit: Number(process.env.COMMENT_RATE_LIMIT || 8) });
const apiRateLimit = rateLimit({ bucket: "api", windowMs: 60 * 1000, limit: Number(process.env.API_RATE_LIMIT || 60) });
const adminRateLimit = rateLimit({ bucket: "admin", windowMs: 60 * 1000, limit: Number(process.env.ADMIN_RATE_LIMIT || 30) });

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use((req, res, next) => {
  res.locals.cspNonce = generateCspNonce();
  next();
});
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      baseUri: ["'self'"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", "data:"],
      imgSrc: ["'self'", "data:", "https:", "blob:"],
      objectSrc: ["'none'"],
      scriptSrc: ["'self'", (req, res) => `'nonce-${res.locals.cspNonce}'`],
      styleSrc: ["'self'"],
      frameAncestors: ["'none'"],
      formAction: ["'self'"],
      upgradeInsecureRequests: appOrigin.startsWith("https://") ? [] : null,
    },
  },
  crossOriginEmbedderPolicy: false,
}));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const sessionStore = await createSessionStore(session);
const sessionCookieSecure = process.env.SESSION_COOKIE_SECURE || (appOrigin.startsWith("https://") ? "auto" : "false");
app.use(session({
  store: sessionStore,
  name: process.env.SESSION_COOKIE_NAME || "mangawave.sid",
  secret: process.env.SESSION_SECRET || "mangawave-dev-session-secret",
  resave: false,
  saveUninitialized: false,
  rolling: false,
  unset: "destroy",
  proxy: Boolean(trustProxy),
  cookie: {
    httpOnly: true,
    sameSite: process.env.SESSION_COOKIE_SAMESITE || "lax",
    secure: sessionCookieSecure === "auto" ? "auto" : sessionCookieSecure === "true",
    maxAge: 1000 * 60 * 60 * 24 * 14,
    path: "/",
  },
}));

function setFlash(req, type, message) {
  req.session.flash = { type, message };
}

function audit(req, event) {
  logAuditEvent(req, event).catch(() => {});
}

function regenerateSession(req) {
  return new Promise((resolve, reject) => {
    req.session.regenerate((error) => {
      if (error) return reject(error);
      resolve();
    });
  });
}

function destroySession(req) {
  return new Promise((resolve) => {
    req.session.destroy(() => resolve());
  });
}

function markRecentAuth(req) {
  req.session.recentAuthAt = Date.now();
}

function hasRecentAuth(req) {
  return Number(req.session.recentAuthAt || 0) >= Date.now() - recentAuthWindowMs;
}

async function signInUser(req, user) {
  await regenerateSession(req);
  req.session.userId = user.id;
  req.session.sessionVersion = user.sessionVersion;
  markRecentAuth(req);
  ensureCsrfToken(req);
}

async function maybeSendVerificationEmail(req, user) {
  if (!emailVerificationEnabled()) return { delivered: false, reason: "disabled" };
  const payload = await createEmailVerification(user.id, appOrigin);
  if (!payload) return { delivered: false, reason: "already-verified" };
  const result = await sendVerificationEmail({
    to: user.email,
    verifyUrl: payload.verifyUrl,
    expiresMinutes: payload.expiresMinutes,
  });
  audit(req, {
    category: "delivery",
    action: "verification_email",
    outcome: result.delivered ? "success" : "skipped",
    actorId: user.id,
    details: { provider: result.provider, emailHash: sha256(user.email) },
  });
  return result;
}

app.use(async (req, res, next) => {
  res.locals.currentPath = req.path;
  res.locals.currentUser = null;
  res.locals.flash = req.session.flash || null;
  delete req.session.flash;

  if (req.session.userId) {
    const user = await findUserById(req.session.userId);
    if (!user || Number(req.session.sessionVersion || 0) !== Number(user.sessionVersion || 0)) {
      audit(req, { category: "auth", action: "session_invalidated", outcome: "success", actorId: req.session.userId });
      delete req.session.userId;
      delete req.session.sessionVersion;
      delete req.session.recentAuthAt;
    } else {
      res.locals.currentUser = user;
    }
  }

  res.locals.storage = getStorageSummary();
  res.locals.dbMode = isPostgresEnabled() ? "postgresql" : "json";
  res.locals.appOrigin = appOrigin;
  res.locals.emailDeliveryEnabled = emailDeliveryEnabled();
  res.locals.emailVerificationEnabled = emailVerificationEnabled();
  res.locals.recentAuth = hasRecentAuth(req);
  res.locals.csrfToken = ensureCsrfToken(req);
  next();
});

function requireAuth(req, res, next) {
  if (!res.locals.currentUser) {
    setFlash(req, "error", "Please log in first.");
    return res.redirect(`/login?next=${encodeURIComponent(req.originalUrl)}`);
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!res.locals.currentUser) {
    setFlash(req, "error", "Admin access requires login.");
    return res.redirect(`/login?next=${encodeURIComponent(req.originalUrl)}`);
  }
  if (res.locals.currentUser.role !== "admin") {
    audit(req, { category: "admin", action: "admin_access_denied", outcome: "failure", actorId: res.locals.currentUser.id });
    return res.status(403).render("pages/error", { pageTitle: "Forbidden • MangaWave", error: new Error("You need an admin account for this page.") });
  }
  next();
}

function requireVerifiedEmail(req, res, next) {
  if (!res.locals.currentUser?.emailVerified) {
    setFlash(req, "error", "Please verify your email before using this action.");
    return res.redirect("/account");
  }
  next();
}

function requireRecentAuth(req, res, next) {
  if (!hasRecentAuth(req)) {
    setFlash(req, "error", "Please confirm your password before changing sensitive settings.");
    return res.redirect(`/reauth?next=${encodeURIComponent(req.originalUrl || "/account")}`);
  }
  next();
}

function sortChaptersAsc(chapters) {
  return [...chapters].sort((a, b) => Number(a.number) - Number(b.number));
}

function sortChaptersDesc(chapters) {
  return [...chapters].sort((a, b) => Number(b.number) - Number(a.number));
}

app.get("/", async (_req, res, next) => {
  try {
    const series = await getAllSeries();
    const featured = series.filter((item) => item.featured).slice(0, 4);
    const latest = series.slice(0, 8);
    const totalChapters = series.reduce((sum, item) => sum + item.chapters.length, 0);
    const userCount = await countUsers();
    res.render("pages/home", { pageTitle: "MangaWave", series, featured, latest, totalChapters, userCount });
  } catch (error) {
    next(error);
  }
});

app.get("/series", async (_req, res, next) => {
  try {
    const series = await getAllSeries();
    const genres = [...new Set(series.flatMap((item) => item.genres))].sort();
    res.render("pages/library", { pageTitle: "Library • MangaWave", series, genres });
  } catch (error) {
    next(error);
  }
});

app.get("/series/:slug", async (req, res, next) => {
  try {
    const series = await getSeriesBySlug(req.params.slug);
    if (!series) return res.status(404).render("pages/not-found", { pageTitle: "Not found • MangaWave" });
    const chapters = sortChaptersDesc(series.chapters);
    const latestChapter = chapters[0] || null;
    const bookmarked = res.locals.currentUser ? await isSeriesBookmarked(res.locals.currentUser.id, series.slug) : false;
    res.render("pages/series-detail", { pageTitle: `${series.title} • MangaWave`, series, chapters, latestChapter, bookmarked });
  } catch (error) {
    next(error);
  }
});

app.get("/read/:seriesSlug/:chapterSlug", async (req, res, next) => {
  try {
    const payload = await getChapter(req.params.seriesSlug, req.params.chapterSlug);
    if (!payload) return res.status(404).render("pages/not-found", { pageTitle: "Not found • MangaWave" });
    const ordered = sortChaptersAsc(payload.series.chapters);
    const currentIndex = ordered.findIndex((item) => item.slug === payload.chapter.slug);
    const previous = currentIndex > 0 ? ordered[currentIndex - 1] : null;
    const nextChapter = currentIndex < ordered.length - 1 ? ordered[currentIndex + 1] : null;
    const comments = await getCommentsForChapter(payload.series.slug, payload.chapter.slug);
    res.render("pages/reader", { pageTitle: `${payload.series.title} Chapter ${payload.chapter.number} • MangaWave`, series: payload.series, chapter: payload.chapter, previous, nextChapter, comments });
  } catch (error) {
    next(error);
  }
});

app.get("/login", (req, res) => {
  if (res.locals.currentUser) return res.redirect("/account");
  res.render("pages/login", { pageTitle: "Login • MangaWave", nextUrl: req.query.next || "/account" });
});

app.get("/register", (req, res) => {
  if (res.locals.currentUser) return res.redirect("/account");
  res.render("pages/register", { pageTitle: "Create account • MangaWave", nextUrl: req.query.next || "/account" });
});

app.get("/forgot-password", (_req, res) => {
  res.render("pages/forgot-password", { pageTitle: "Reset password • MangaWave" });
});

app.get("/reset-password", async (req, res, next) => {
  try {
    const token = String(req.query.token || "");
    const reset = token ? await getPasswordResetByToken(token) : null;
    const validToken = Boolean(reset && new Date(reset.expires_at || reset.expiresAt).getTime() >= Date.now());
    res.render("pages/reset-password", { pageTitle: "Set new password • MangaWave", token, validToken });
  } catch (error) {
    next(error);
  }
});

app.get("/reauth", requireAuth, (req, res) => {
  res.render("pages/reauth", { pageTitle: "Confirm password • MangaWave", nextUrl: req.query.next || "/account" });
});

app.get("/verify-email", async (req, res) => {
  try {
    const user = await completeEmailVerification(String(req.query.token || ""));
    audit(req, { category: "delivery", action: "email_verify", outcome: "success", actorId: user.id, details: { emailHash: sha256(user.email) } });
    setFlash(req, "success", "Email verified.");
    res.redirect(req.session.userId ? "/account" : "/login");
  } catch (error) {
    audit(req, { category: "delivery", action: "email_verify", outcome: "failure", details: { reason: error.message } });
    setFlash(req, "error", error.message || "Could not verify email.");
    res.redirect(req.session.userId ? "/account" : "/login");
  }
});

app.post("/login", authRateLimit, csrfProtection, async (req, res, next) => {
  try {
    const email = String(req.body.email || "");
    const user = await verifyUser(email, String(req.body.password || ""));
    if (!user) {
      audit(req, { category: "auth", action: "login", outcome: "failure", details: { emailHash: sha256(email.toLowerCase()) } });
      setFlash(req, "error", "Wrong email or password.");
      return res.redirect(`/login?next=${encodeURIComponent(req.body.next || "/account")}`);
    }

    await signInUser(req, user);
    audit(req, { category: "auth", action: "login", outcome: "success", actorId: user.id });
    setFlash(req, "success", `Welcome back, ${user.username}.`);
    res.redirect(req.body.next || "/account");
  } catch (error) {
    next(error);
  }
});

app.post("/register", authRateLimit, csrfProtection, async (req, res) => {
  try {
    const password = String(req.body.password || "");
    const confirmPassword = String(req.body.confirmPassword || "");
    if (password !== confirmPassword) throw new Error("Passwords do not match.");
    const user = await createUser({ email: String(req.body.email || ""), username: String(req.body.username || ""), password });
    await signInUser(req, user);
    await maybeSendVerificationEmail(req, user);
    audit(req, { category: "auth", action: "register", outcome: "success", actorId: user.id });
    const message = emailVerificationEnabled() ? `Account created. Welcome, ${user.username}. Check your email for verification.` : `Account created. Welcome, ${user.username}.`;
    setFlash(req, "success", message);
    res.redirect(req.body.next || "/account");
  } catch (error) {
    audit(req, { category: "auth", action: "register", outcome: "failure", details: { reason: error.message } });
    setFlash(req, "error", error.message || "Could not create account.");
    res.redirect(`/register?next=${encodeURIComponent(req.body.next || "/account")}`);
  }
});

app.post("/forgot-password", forgotIpRateLimit, csrfProtection, async (req, res) => {
  const startedAt = Date.now();
  const email = String(req.body.email || "").toLowerCase().trim();
  try {
    const accountLimiter = await consumeRateLimit({
      bucket: "forgot-account",
      key: sha256(email || "missing"),
      windowMs: 10 * 60 * 1000,
      limit: Number(process.env.FORGOT_ACCOUNT_RATE_LIMIT || 3),
    });

    if (accountLimiter.allowed) {
      const payload = await createPasswordReset(email, appOrigin);
      if (payload) {
        const delivery = await sendPasswordResetEmail({
          to: payload.user.email,
          resetUrl: payload.resetUrl,
          expiresMinutes: payload.expiresMinutes,
        });
        audit(req, { category: "delivery", action: "password_reset_email", outcome: delivery.delivered ? "success" : "skipped", targetId: payload.user.id, details: { provider: delivery.provider, emailHash: sha256(payload.user.email) } });
      } else {
        audit(req, { category: "auth", action: "forgot_password", outcome: "success", details: { emailHash: sha256(email), resetIssued: false } });
      }
    } else {
      audit(req, { category: "auth", action: "forgot_password", outcome: "throttled", details: { emailHash: sha256(email) } });
    }
  } catch {
    audit(req, { category: "auth", action: "forgot_password", outcome: "failure", details: { emailHash: sha256(email) } });
  }

  await enforceUniformTiming(startedAt, Number(process.env.FORGOT_PASSWORD_MIN_MS || 700));
  setFlash(req, "success", forgotPasswordMessage);
  res.redirect("/forgot-password");
});

app.post("/reset-password", authRateLimit, csrfProtection, async (req, res) => {
  try {
    const password = String(req.body.password || "");
    const confirmPassword = String(req.body.confirmPassword || "");
    if (password !== confirmPassword) throw new Error("Passwords do not match.");
    const user = await completePasswordReset(String(req.body.token || ""), password);
    audit(req, { category: "auth", action: "reset_password", outcome: "success", actorId: user.id });
    setFlash(req, "success", "Password reset complete. Log in with the new password.");
    res.redirect("/login");
  } catch (error) {
    audit(req, { category: "auth", action: "reset_password", outcome: "failure", details: { reason: error.message } });
    setFlash(req, "error", error.message || "Could not reset password.");
    res.redirect(`/reset-password?token=${encodeURIComponent(req.body.token || "")}`);
  }
});

app.post("/reauth", requireAuth, authRateLimit, csrfProtection, async (req, res) => {
  try {
    const user = await verifyUser(res.locals.currentUser.email, String(req.body.password || ""));
    if (!user || user.id !== res.locals.currentUser.id) throw new Error("Password confirmation failed.");
    markRecentAuth(req);
    audit(req, { category: "auth", action: "reauth", outcome: "success", actorId: user.id });
    setFlash(req, "success", "Password confirmed.");
    res.redirect(req.body.next || "/account");
  } catch (error) {
    audit(req, { category: "auth", action: "reauth", outcome: "failure", actorId: res.locals.currentUser.id, details: { reason: error.message } });
    setFlash(req, "error", error.message || "Could not confirm password.");
    res.redirect(`/reauth?next=${encodeURIComponent(req.body.next || "/account")}`);
  }
});

app.post("/account/password", requireAuth, requireRecentAuth, authRateLimit, csrfProtection, async (req, res) => {
  try {
    const newPassword = String(req.body.newPassword || "");
    const confirmPassword = String(req.body.confirmPassword || "");
    if (newPassword !== confirmPassword) throw new Error("New passwords do not match.");
    const user = await changePassword(res.locals.currentUser.id, String(req.body.currentPassword || ""), newPassword);
    await signInUser(req, user);
    audit(req, { category: "auth", action: "change_password", outcome: "success", actorId: user.id });
    setFlash(req, "success", "Password updated.");
    res.redirect("/account");
  } catch (error) {
    audit(req, { category: "auth", action: "change_password", outcome: "failure", actorId: res.locals.currentUser.id, details: { reason: error.message } });
    setFlash(req, "error", error.message || "Could not update password.");
    res.redirect("/account");
  }
});

app.post("/account/verify-email/resend", requireAuth, verificationResendRateLimit, csrfProtection, async (req, res) => {
  try {
    if (!emailVerificationEnabled()) {
      setFlash(req, "error", "Email verification is not enabled on this deployment.");
      return res.redirect("/account");
    }
    const delivery = await maybeSendVerificationEmail(req, res.locals.currentUser);
    const message = delivery.delivered ? "Verification email sent." : "Verification email not sent.";
    setFlash(req, delivery.delivered ? "success" : "error", message);
    res.redirect("/account");
  } catch (error) {
    audit(req, { category: "delivery", action: "verification_email", outcome: "failure", actorId: res.locals.currentUser.id, details: { reason: error.message } });
    setFlash(req, "error", error.message || "Could not send verification email.");
    res.redirect("/account");
  }
});

app.post("/logout", csrfProtection, async (req, res) => {
  audit(req, { category: "auth", action: "logout", outcome: "success", actorId: req.session.userId || null });
  await destroySession(req);
  res.redirect("/");
});

app.get("/account", requireAuth, async (_req, res, next) => {
  try {
    const series = await getAllSeries();
    const stats = {
      seriesCount: series.length,
      chapterCount: series.reduce((sum, item) => sum + item.chapters.length, 0),
      featuredCount: series.filter((item) => item.featured).length,
    };
    const [bookmarks, progress] = await Promise.all([
      getBookmarksForUser(res.locals.currentUser.id),
      getProgressForUser(res.locals.currentUser.id),
    ]);
    const seriesMap = new Map(series.map((item) => [item.slug, item]));
    const bookmarkCards = bookmarks.map((item) => ({ ...item, series: seriesMap.get(item.seriesSlug) || null })).filter((item) => item.series);
    const progressCards = progress.map((item) => ({ ...item, series: seriesMap.get(item.seriesSlug) || null })).filter((item) => item.series);
    res.render("pages/account", { pageTitle: "Account • MangaWave", stats, bookmarkCards, progressCards });
  } catch (error) {
    next(error);
  }
});

app.post("/bookmark/toggle", requireAuth, csrfProtection, async (req, res, next) => {
  try {
    await toggleBookmark(res.locals.currentUser.id, {
      seriesSlug: String(req.body.seriesSlug || ""),
      chapterSlug: String(req.body.chapterSlug || ""),
      chapterLabel: String(req.body.chapterLabel || ""),
    });
    setFlash(req, "success", "Bookmark updated.");
    res.redirect(req.body.returnTo || "/account");
  } catch (error) {
    next(error);
  }
});

app.post("/api/progress", requireAuth, apiRateLimit, csrfProtection, async (req, res, next) => {
  try {
    await upsertProgress(res.locals.currentUser.id, {
      seriesSlug: String(req.body.seriesSlug || ""),
      chapterSlug: String(req.body.chapterSlug || ""),
      chapterLabel: String(req.body.chapterLabel || ""),
    });
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.post("/comments", requireAuth, requireVerifiedEmail, commentRateLimit, csrfProtection, async (req, res) => {
  try {
    await addComment(res.locals.currentUser, {
      seriesSlug: String(req.body.seriesSlug || ""),
      chapterSlug: String(req.body.chapterSlug || ""),
      body: String(req.body.body || ""),
    });
    audit(req, { category: "moderation", action: "comment_create", outcome: "success", actorId: res.locals.currentUser.id });
    setFlash(req, "success", "Comment posted.");
    res.redirect(req.body.returnTo || "/account");
  } catch (error) {
    audit(req, { category: "moderation", action: "comment_create", outcome: "failure", actorId: res.locals.currentUser.id, details: { reason: error.message } });
    setFlash(req, "error", error.message || "Could not post comment.");
    res.redirect(req.body.returnTo || "/account");
  }
});

app.post("/comments/:id/delete", requireAuth, csrfProtection, async (req, res) => {
  try {
    await deleteComment(req.params.id, res.locals.currentUser);
    audit(req, { category: "moderation", action: "comment_delete", outcome: "success", actorId: res.locals.currentUser.id, targetId: req.params.id });
    setFlash(req, "success", "Comment deleted.");
    res.redirect(req.body.returnTo || "/account");
  } catch (error) {
    audit(req, { category: "moderation", action: "comment_delete", outcome: "failure", actorId: res.locals.currentUser.id, targetId: req.params.id, details: { reason: error.message } });
    setFlash(req, "error", error.message || "Could not delete comment.");
    res.redirect(req.body.returnTo || "/account");
  }
});

app.get("/admin", requireAdmin, requireVerifiedEmail, async (_req, res, next) => {
  try {
    const [series, recentComments] = await Promise.all([getAllSeries(), getRecentComments(12)]);
    res.render("pages/admin", { pageTitle: "Admin • MangaWave", series, recentComments, feedback: { type: null, message: null } });
  } catch (error) {
    next(error);
  }
});

app.post("/admin/series", requireAdmin, requireVerifiedEmail, adminRateLimit, csrfProtection, upload.fields([{ name: "cover", maxCount: 1 }, { name: "banner", maxCount: 1 }]), async (req, res, next) => {
  try {
    const existingSeries = await getAllSeries();
    const title = String(req.body.title || "").trim();
    const shortDescription = String(req.body.shortDescription || "").trim();
    const description = String(req.body.description || "").trim();
    if (!title || !shortDescription || !description) throw new Error("Title, short description, and description are required.");
    const slug = slugify(title);
    if (existingSeries.some((item) => item.slug === slug)) throw new Error("A series with that title already exists.");
    const coverAsset = req.files?.cover?.[0] ? await uploadBuffer({ buffer: req.files.cover[0].buffer, originalname: req.files.cover[0].originalname, relativeDir: `covers/${slug}`, rootDir: __dirname, kind: "cover" }) : { url: "/generated/default-cover.svg", thumbnailUrl: "/generated/default-cover.svg" };
    const bannerAsset = req.files?.banner?.[0] ? await uploadBuffer({ buffer: req.files.banner[0].buffer, originalname: req.files.banner[0].originalname, relativeDir: `banners/${slug}`, rootDir: __dirname, kind: "banner" }) : { url: "/generated/default-banner.svg", thumbnailUrl: "/generated/default-banner.svg" };
    await createSeriesEntry({
      id: `series_${Date.now()}`,
      slug,
      title,
      shortDescription,
      description,
      coverImage: coverAsset.url,
      coverThumbImage: coverAsset.thumbnailUrl,
      bannerImage: bannerAsset.url,
      bannerThumbImage: bannerAsset.thumbnailUrl,
      author: String(req.body.author || "Unknown").trim() || "Unknown",
      artist: String(req.body.artist || req.body.author || "Unknown").trim() || "Unknown",
      status: req.body.status || "Ongoing",
      type: req.body.type || "Manhwa",
      featured: req.body.featured === "on",
      mature: req.body.mature === "on",
      updatedAt: new Date().toISOString(),
      tags: String(req.body.tags || "").split(",").map((value) => value.trim()).filter(Boolean),
      genres: String(req.body.genres || "").split(",").map((value) => value.trim()).filter(Boolean),
      chapters: [],
    });
    audit(req, { category: "admin", action: "series_create", outcome: "success", actorId: res.locals.currentUser.id, details: { slug } });
    setFlash(req, "success", "Series created.");
    res.redirect("/admin");
  } catch (error) {
    audit(req, { category: "admin", action: "series_create", outcome: "failure", actorId: res.locals.currentUser.id, details: { reason: error.message } });
    next(error);
  }
});

app.post("/admin/chapter", requireAdmin, requireVerifiedEmail, adminRateLimit, csrfProtection, upload.array("pages", 200), async (req, res, next) => {
  try {
    const series = await getSeriesBySlug(String(req.body.seriesSlug || ""));
    if (!series) throw new Error("Series not found.");
    const number = Number(req.body.number);
    if (!req.files?.length) throw new Error("At least one page image is required.");
    if (!number) throw new Error("Chapter number is required.");
    const chapterSlug = `chapter-${String(number).replace(/\.0+$/, "")}`;
    if (series.chapters.some((item) => item.slug === chapterSlug)) throw new Error("This chapter already exists.");
    const pages = [];
    for (const file of req.files) {
      const asset = await uploadBuffer({ buffer: file.buffer, originalname: file.originalname, relativeDir: `chapters/${series.slug}/${chapterSlug}`, rootDir: __dirname, kind: "page" });
      pages.push(asset.url);
    }
    await createChapterEntry(series.slug, {
      id: `chapter_${Date.now()}`,
      title: String(req.body.title || `Chapter ${number}`).trim(),
      slug: chapterSlug,
      number,
      publishedAt: new Date().toISOString(),
      pages,
      estimatedMinutes: Number(req.body.estimatedMinutes || 0) || undefined,
    });
    audit(req, { category: "admin", action: "chapter_create", outcome: "success", actorId: res.locals.currentUser.id, details: { seriesSlug: series.slug, chapterSlug } });
    setFlash(req, "success", "Chapter uploaded.");
    res.redirect(`/series/${series.slug}`);
  } catch (error) {
    audit(req, { category: "admin", action: "chapter_create", outcome: "failure", actorId: res.locals.currentUser.id, details: { reason: error.message } });
    next(error);
  }
});

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).render("pages/error", { pageTitle: "Error • MangaWave", error });
});

await ensureBasePaths(__dirname);
await initDatabase();
await ensureSeedAdmin();
app.listen(port, () => {
  console.log(`MangaWave running on ${appOrigin}`);
});
