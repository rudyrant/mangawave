const historyKey = "mangawave-reading-history";
const bookmarkKey = "mangawave-bookmarks";

function readStore(key) {
  try {
    return JSON.parse(localStorage.getItem(key) || "[]");
  } catch {
    localStorage.removeItem(key);
    return [];
  }
}

function writeStore(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

(function libraryFilters() {
  const search = document.querySelector("#library-search");
  const genre = document.querySelector("#library-genre");
  const cards = [...document.querySelectorAll(".searchable-series")];
  const empty = document.querySelector("#empty-library");
  if (!search || !genre || !cards.length) return;

  const update = () => {
    const query = search.value.trim().toLowerCase();
    const wantedGenre = genre.value;
    let visible = 0;
    cards.forEach((card) => {
      const haystack = card.dataset.search || "";
      const genres = (card.dataset.genres || "").split("|").filter(Boolean);
      const match = haystack.includes(query) && (wantedGenre === "All" || genres.includes(wantedGenre));
      card.classList.toggle("hidden", !match);
      if (match) visible += 1;
    });
    empty?.classList.toggle("hidden", visible !== 0);
  };

  search.addEventListener("input", update);
  genre.addEventListener("change", update);
})();

(function guestBookmarkButtons() {
  const buttons = [...document.querySelectorAll("[data-bookmark-mode='guest']")];
  if (!buttons.length) return;
  const bookmarks = readStore(bookmarkKey);

  const refresh = () => {
    buttons.forEach((button) => {
      const exists = bookmarks.some((entry) => entry.seriesSlug === button.dataset.bookmarkSeries);
      button.textContent = exists ? "Bookmarked on this device" : "Bookmark on this device";
    });
  };

  refresh();
  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      const seriesSlug = button.dataset.bookmarkSeries;
      const existingIndex = bookmarks.findIndex((entry) => entry.seriesSlug === seriesSlug);
      if (existingIndex >= 0) {
        bookmarks.splice(existingIndex, 1);
      } else {
        bookmarks.unshift({
          seriesSlug,
          chapterSlug: button.dataset.bookmarkChapter,
          chapterLabel: button.dataset.bookmarkLabel,
          updatedAt: new Date().toISOString(),
        });
      }
      writeStore(bookmarkKey, bookmarks);
      refresh();
    });
  });
})();

(function renderHistory() {
  const panel = document.querySelector("#history-panel");
  const library = window.__MW_LIBRARY__;
  if (!panel || !Array.isArray(library)) return;
  const history = readStore(historyKey);
  if (!history.length) return;
  panel.innerHTML = "";
  history.forEach((entry) => {
    const meta = library.find((item) => item.seriesSlug === entry.seriesSlug);
    if (!meta) return;
    const anchor = document.createElement("a");
    anchor.href = `/read/${entry.seriesSlug}/${entry.chapterSlug}`;
    anchor.className = "history-item";
    anchor.innerHTML = `
      <img src="${meta.coverImage}" alt="${meta.title}" />
      <div>
        <strong>${meta.title}</strong>
        <div class="muted">Resume ${entry.chapterLabel}</div>
        <div class="muted">Latest available: ${meta.latestChapterLabel}</div>
      </div>
    `;
    panel.appendChild(anchor);
  });
})();

(function trackReader() {
  const reader = window.__MW_READER__;
  if (!reader) return;

  const history = readStore(historyKey).filter((entry) => entry.seriesSlug !== reader.seriesSlug);
  history.unshift({
    seriesSlug: reader.seriesSlug,
    chapterSlug: reader.chapterSlug,
    chapterLabel: reader.chapterLabel,
    updatedAt: new Date().toISOString(),
  });
  writeStore(historyKey, history.slice(0, 12));

  if (!reader.loggedIn) return;
  fetch("/api/progress", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-csrf-token": reader.csrfToken,
    },
    body: JSON.stringify({
      seriesSlug: reader.seriesSlug,
      chapterSlug: reader.chapterSlug,
      chapterLabel: reader.chapterLabel,
    }),
  }).catch(() => {});
})();
